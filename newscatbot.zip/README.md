# NewscatBot
BOT newscat<br>
<br>
Install termux on Play Store before using this bot<br>
Write this command one by one on termux apps<br>
<br>
apt upgrade && apt update<br>
apt install python2<br>
apt install git<br>
git clone https://github.com/drakhaw/newscatbot<br>
apt install curl<br>
apt install grep<br>
cd newscatbot<br>
bash newscat.sh<br>
<br>
This script is free to use without any referrals and any conditions<br>
<br>
<font color="red">PS : Don't forget to give a stars to support my work</font>
